CREATE DATABASE WeatherForecast;
USE WeatherForecast;


CREATE TABLE Location (
    LocationID INT PRIMARY KEY,
    City VARCHAR(50),
    Country VARCHAR(50),
    Latitude DECIMAL(10, 6),
    Longitude DECIMAL(10, 6)
);

CREATE TABLE Sensor (
    SensorID INT PRIMARY KEY,
    LocationID INT,
    SensorType VARCHAR(30),
    InstallationDate DATE,
    Status VARCHAR(15),
    FOREIGN KEY (LocationID) REFERENCES Location(LocationID)
);

CREATE TABLE WeatherRecord (
    RecordID INT PRIMARY KEY,
    SensorID INT,
    Timestamp DATETIME,
    Temperature DECIMAL(5, 2),
    Humidity DECIMAL(4, 1),
    WindSpeed DECIMAL(4, 1),
    Precipitation DECIMAL(4, 2),
    FOREIGN KEY (SensorID) REFERENCES Sensor(SensorID)
);

CREATE TABLE HistoricalWeatherData (
    HistoryID INT PRIMARY KEY,
    LocationID INT,
    Date DATE,
    AverageTemperature DECIMAL(5, 2),
    AverageHumidity DECIMAL(4, 1),
    TotalPrecipitation DECIMAL(5, 2),
    MaxWindSpeed DECIMAL(4, 1),
    FOREIGN KEY (LocationID) REFERENCES Location(LocationID)
);

CREATE TABLE WeatherType (
    WeatherTypeID INT PRIMARY KEY,
    Description VARCHAR(50),
    SeverityLevel INT
);

CREATE TABLE Forecast (
    ForecastID INT PRIMARY KEY,
    LocationID INT,
    ForecastDate DATE,
    PredictedTemperature DECIMAL(5, 2),
    PredictedHumidity DECIMAL(4, 1),
    PredictedPrecipitation DECIMAL(4, 2),
    FOREIGN KEY (LocationID) REFERENCES Location(LocationID)
);

CREATE TABLE User (
    UserID INT PRIMARY KEY,
    Username VARCHAR(50),
    Email VARCHAR(100),
    Password VARCHAR(255),
    UserType VARCHAR(20)
);

CREATE TABLE Subscription (
    SubscriptionID INT PRIMARY KEY,
    UserID INT,
    LocationID INT,
    AlertType VARCHAR(30),
    SubscriptionDate DATE,
    FOREIGN KEY (UserID) REFERENCES User(UserID),
    FOREIGN KEY (LocationID) REFERENCES Location(LocationID)
);

CREATE TABLE Alert (
    AlertID INT PRIMARY KEY,
    LocationID INT,
    AlertType VARCHAR(30),
    AlertMessage TEXT,
    AlertDate DATETIME,
    FOREIGN KEY (LocationID) REFERENCES Location(LocationID)
);

CREATE TABLE APILog (
    LogID INT PRIMARY KEY,
    UserID INT,
    RequestTimestamp DATETIME,
    EndpointAccessed VARCHAR(100),
    RequestStatus VARCHAR(15),
    FOREIGN KEY (UserID) REFERENCES User(UserID)
);

-- Inserting diverse countries in the Location table
INSERT INTO Location (LocationID, City, Country, Latitude, Longitude) VALUES
(1, 'New York', 'USA', 40.7128, -74.0060),
(2, 'Toronto', 'Canada', 43.65107, -79.347015),
(3, 'Mumbai', 'India', 19.0760, 72.8777),
(4, 'Cape Town', 'South Africa', -33.9249, 18.4241),
(5, 'Beijing', 'China', 39.9042, 116.4074);


INSERT INTO Sensor (SensorID, LocationID, SensorType, InstallationDate, Status) VALUES
(1, 1, 'Temperature', '2023-01-15', 'Active'),
(2, 1, 'Humidity', '2023-01-16', 'Active'),
(3, 2, 'Wind Speed', '2022-05-22', 'Active'),
(4, 3, 'Precipitation', '2021-12-10', 'Maintenance'),
(5, 4, 'Temperature', '2023-06-01', 'Active');

INSERT INTO WeatherRecord (RecordID, SensorID, Timestamp, Temperature, Humidity, WindSpeed, Precipitation) VALUES
(1, 1, '2024-11-06 10:00:00', 15.6, NULL, NULL, NULL),
(2, 2, '2024-11-06 10:05:00', NULL, 82.0, NULL, NULL),
(3, 3, '2024-11-06 10:10:00', NULL, NULL, 12.0, NULL),
(4, 4, '2024-11-06 10:15:00', NULL, NULL, NULL, 0.5),
(5, 5, '2024-11-06 10:20:00', 22.4, NULL, NULL, NULL);

INSERT INTO HistoricalWeatherData (HistoryID, LocationID, Date, AverageTemperature, AverageHumidity, TotalPrecipitation, MaxWindSpeed) VALUES
(1, 1, '2023-11-06', 12.5, 80.0, 5.2, 20.3),
(2, 2, '2023-11-06', 14.3, 77.0, 3.5, 18.4),
(3, 3, '2023-11-06', 18.7, 70.0, 4.0, 25.6),
(4, 4, '2023-11-06', 23.1, 65.0, 2.8, 15.2),
(5, 5, '2023-11-06', 17.2, 85.0, 6.3, 22.8);

INSERT INTO WeatherType (WeatherTypeID, Description, SeverityLevel) VALUES
(1, 'Clear', 1),
(2, 'Rain', 2),
(3, 'Snow', 3),
(4, 'Thunderstorm', 4),
(5, 'Extreme Heat', 5);

INSERT INTO Forecast (ForecastID, LocationID, ForecastDate, PredictedTemperature, PredictedHumidity, PredictedPrecipitation) VALUES
(1, 1, '2024-11-07', 16.5, 78.0, 0.6),
(2, 2, '2024-11-07', 13.8, 82.0, 1.2),
(3, 3, '2024-11-07', 20.1, 68.0, 0.3),
(4, 4, '2024-11-07', 24.6, 60.0, 0.0),
(5, 5, '2024-11-07', 19.4, 90.0, 5.1);

INSERT INTO User (UserID, Username, Email, Password, UserType) VALUES
(1, 'rajiv sharma', 'rajivsharma@globalweather.com', 'password1', 'Meteorologist'),
(2, 'sophia brown', 'sophiabrown@globalweather.com', 'password2', 'Researcher'),
(3, 'aakash kapoor', 'aakashkapoor@globalweather.com', 'password3', 'General Public'),
(4, 'olivia martin', 'oliviamartin@globalweather.com', 'password4', 'Professor'),
(5, 'veer patel', 'veerpatel@globalweather.com', 'password5', 'General Public');


INSERT INTO Subscription (SubscriptionID, UserID, LocationID, AlertType, SubscriptionDate) VALUES
(1, 1, 1, 'Daily Forecast', '2024-01-01'),
(2, 2, 2, 'Extreme Weather', '2024-01-02'),
(3, 3, 3, 'Severe Storm', '2024-01-03'),
(4, 4, 4, 'Daily Forecast', '2024-01-04'),
(5, 5, 5, 'Heat Wave', '2024-01-05');

INSERT INTO Alert (AlertID, LocationID, AlertType, AlertMessage, AlertDate) VALUES
(1, 1, 'Severe Storm', 'Severe storm warning in New York', '2024-11-06 12:00:00'),
(2, 2, 'Heavy Rain', 'Expect heavy rain in Toronto', '2024-11-06 12:00:00'),
(3, 3, 'Earthquake', 'Earthquake detected near mumbai in india', '2024-11-06 12:00:00'),
(4, 4, 'Heat Wave', 'High temperatures expected in South africa', '2024-11-06 12:00:00'),
(5, 5, 'Flood Warning', 'Flood risk in Cape Beijing', '2024-11-06 12:00:00');

INSERT INTO APILog (LogID, UserID, RequestTimestamp, EndpointAccessed, RequestStatus) VALUES
(1, 1, '2024-11-06 09:00:00', '/weather/current', 'Success'),
(2, 2, '2024-11-06 09:05:00', '/weather/forecast', 'Success'),
(3, 3, '2024-11-06 09:10:00', '/weather/history', 'Failed'),
(4, 4, '2024-11-06 09:15:00', '/weather/alerts', 'Success'),
(5, 5, '2024-11-06 09:20:00', '/weather/current', 'Success');

-- 1
SELECT F.LocationID, L.City, F.ForecastDate, F.PredictedTemperature
FROM Forecast F
JOIN Location L ON F.LocationID = L.LocationID
WHERE F.PredictedTemperature > (
    SELECT AVG(PredictedTemperature)
    FROM Forecast
    WHERE ForecastDate = '2024-11-07'
);

-- 2
INSERT INTO Forecast (ForecastID, LocationID, ForecastDate, PredictedTemperature, PredictedHumidity, PredictedPrecipitation)
VALUES (6, 3, '2024-11-07', 21.0, 75.0, 1.5);
SELECT * FROM Forecast;

-- 3
UPDATE Sensor
SET Status = 'Inactive'
WHERE SensorID = 4 AND LocationID = 3;
SELECT * FROM Sensor;

-- 4
SELECT MAX(Temperature) AS MaxTemperature
FROM WeatherRecord w
JOIN Sensor s ON w.SensorID = s.SensorID
JOIN Location l ON s.LocationID = l.LocationID
WHERE l.City = 'New York' AND MONTH(w.Timestamp) = 11 AND YEAR(w.Timestamp) = 2024;


-- 5
SELECT AlertMessage, AlertDate
FROM Alert a
JOIN Location l ON a.LocationID = l.LocationID
WHERE l.City = 'Toronto' AND a.AlertType = 'Heavy Rain';

-- 6
SELECT l.City, h.MaxWindSpeed
FROM HistoricalWeatherData h
JOIN Location l ON h.LocationID = l.LocationID
WHERE h.Date = '2023-11-06'
ORDER BY h.MaxWindSpeed DESC
LIMIT 1; 



-- 7
SELECT l.City, MAX(a.AlertDate) AS LatestAlertDate, MIN(a.AlertDate) AS EarliestAlertDate
FROM Alert a
JOIN Location l ON a.LocationID = l.LocationID
GROUP BY l.City
HAVING COUNT(a.AlertID) >= 1;

-- 8
SELECT l.City, COUNT(u.UserID) AS UserCount
FROM Subscription s
JOIN User u ON s.UserID = u.UserID
JOIN Location l ON s.LocationID = l.LocationID
WHERE s.AlertType = 'Extreme Weather'
GROUP BY l.City;

-- 9
SELECT u.Username, al.RequestTimestamp, al.EndpointAccessed, al.RequestStatus
FROM APILog al
JOIN User u ON al.UserID = u.UserID
WHERE al.RequestStatus = 'Failed'
ORDER BY al.RequestTimestamp DESC
LIMIT 5;

-- 10
SELECT f.ForecastDate, f.PredictedTemperature, f.PredictedHumidity, f.PredictedPrecipitation, l.City, l.Country
FROM Forecast f
JOIN Location l ON f.LocationID = l.LocationID
WHERE l.City = 'New York' AND l.Country = 'USA'
ORDER BY f.ForecastDate;




